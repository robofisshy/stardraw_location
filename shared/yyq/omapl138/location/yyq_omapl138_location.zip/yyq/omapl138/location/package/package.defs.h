/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-z52
 */

#ifndef yyq_omapl138_location__
#define yyq_omapl138_location__



#endif /* yyq_omapl138_location__ */ 
